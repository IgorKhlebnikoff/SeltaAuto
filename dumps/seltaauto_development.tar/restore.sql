--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
DROP INDEX public.index_users_on_reset_password_token;
DROP INDEX public.index_users_on_email;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.service_types DROP CONSTRAINT service_types_pkey;
ALTER TABLE ONLY public.inspection_requests DROP CONSTRAINT inspection_requests_pkey;
ALTER TABLE ONLY public.inspection_request_service_types DROP CONSTRAINT inspection_request_service_types_pkey;
ALTER TABLE ONLY public.contents DROP CONSTRAINT contents_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.service_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inspection_requests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inspection_request_service_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.contents ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.service_types_id_seq;
DROP TABLE public.service_types;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.inspection_requests_id_seq;
DROP TABLE public.inspection_requests;
DROP SEQUENCE public.inspection_request_service_types_id_seq;
DROP TABLE public.inspection_request_service_types;
DROP SEQUENCE public.contents_id_seq;
DROP TABLE public.contents;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: Pro
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO "Pro";

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: Pro
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: contents; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE contents (
    id integer NOT NULL,
    name character varying(255),
    description text,
    picture_file_name character varying(255),
    picture_content_type character varying(255),
    picture_file_size integer,
    picture_updated_at timestamp without time zone,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    user_id integer
);


ALTER TABLE public.contents OWNER TO postgres;

--
-- Name: contents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE contents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contents_id_seq OWNER TO postgres;

--
-- Name: contents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE contents_id_seq OWNED BY contents.id;


--
-- Name: inspection_request_service_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE inspection_request_service_types (
    id integer NOT NULL,
    inspection_request_id integer,
    service_type_id integer
);


ALTER TABLE public.inspection_request_service_types OWNER TO postgres;

--
-- Name: inspection_request_service_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inspection_request_service_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inspection_request_service_types_id_seq OWNER TO postgres;

--
-- Name: inspection_request_service_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inspection_request_service_types_id_seq OWNED BY inspection_request_service_types.id;


--
-- Name: inspection_requests; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE inspection_requests (
    id integer NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    phone_number character varying(255),
    comment text,
    viewed boolean DEFAULT false,
    viewed_by_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.inspection_requests OWNER TO postgres;

--
-- Name: inspection_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inspection_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inspection_requests_id_seq OWNER TO postgres;

--
-- Name: inspection_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inspection_requests_id_seq OWNED BY inspection_requests.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: service_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE service_types (
    id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public.service_types OWNER TO postgres;

--
-- Name: service_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE service_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_types_id_seq OWNER TO postgres;

--
-- Name: service_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE service_types_id_seq OWNED BY service_types.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying(255) DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying(255),
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying(255),
    last_sign_in_ip character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY contents ALTER COLUMN id SET DEFAULT nextval('contents_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inspection_request_service_types ALTER COLUMN id SET DEFAULT nextval('inspection_request_service_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inspection_requests ALTER COLUMN id SET DEFAULT nextval('inspection_requests_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY service_types ALTER COLUMN id SET DEFAULT nextval('service_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: contents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY contents (id, name, description, picture_file_name, picture_content_type, picture_file_size, picture_updated_at, type, created_at, updated_at, user_id) FROM stdin;
\.
COPY contents (id, name, description, picture_file_name, picture_content_type, picture_file_size, picture_updated_at, type, created_at, updated_at, user_id) FROM '$$PATH$$/2259.dat';

--
-- Name: contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('contents_id_seq', 6, true);


--
-- Data for Name: inspection_request_service_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inspection_request_service_types (id, inspection_request_id, service_type_id) FROM stdin;
\.
COPY inspection_request_service_types (id, inspection_request_id, service_type_id) FROM '$$PATH$$/2255.dat';

--
-- Name: inspection_request_service_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inspection_request_service_types_id_seq', 1, false);


--
-- Data for Name: inspection_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inspection_requests (id, first_name, last_name, phone_number, comment, viewed, viewed_by_id, created_at, updated_at) FROM stdin;
\.
COPY inspection_requests (id, first_name, last_name, phone_number, comment, viewed, viewed_by_id, created_at, updated_at) FROM '$$PATH$$/2251.dat';

--
-- Name: inspection_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inspection_requests_id_seq', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2249.dat';

--
-- Data for Name: service_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY service_types (id, name) FROM stdin;
\.
COPY service_types (id, name) FROM '$$PATH$$/2253.dat';

--
-- Name: service_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('service_types_id_seq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at) FROM stdin;
\.
COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at) FROM '$$PATH$$/2257.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Name: contents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY contents
    ADD CONSTRAINT contents_pkey PRIMARY KEY (id);


--
-- Name: inspection_request_service_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY inspection_request_service_types
    ADD CONSTRAINT inspection_request_service_types_pkey PRIMARY KEY (id);


--
-- Name: inspection_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY inspection_requests
    ADD CONSTRAINT inspection_requests_pkey PRIMARY KEY (id);


--
-- Name: service_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY service_types
    ADD CONSTRAINT service_types_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: Pro
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM "Pro";
GRANT ALL ON SCHEMA public TO "Pro";
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

